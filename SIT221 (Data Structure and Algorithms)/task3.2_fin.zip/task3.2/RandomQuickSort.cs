using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3._2
{
    // Bubble Sort
    public class RandomizedQuickSort : ISorter
    {

        //public static void RandQuickSort<K>(K[] sequence, int left, int right) where K : IComparable<K>
        //{
        //    if (left < right)
        //    {
        //        int q = RandomizedPartition(sequence, left, right);
        //        RandQuickSort(sequence, left, q - 1);
        //        RandQuickSort(sequence, q + 1, right);
        //    }
        //}
        //private static int RandomizedPartition<K>(K[] sequence, int left, int right) where K : IComparable<K>
        //{
        //    Random random = new Random();
        //    int i = (left + random.Next()) % (right - left + 1);

        //    K pivot = sequence[i];
        //    sequence[i] = sequence[right];
        //    sequence[right] = pivot;

        //    return Partition(sequence, left, right);
        //}
        //private static int Partition<K>(K[] sequence, int left, int right) where K : IComparable<K>
        //{
        //    K pivot = sequence[right];
        //    K temp;

        //    int i = left - 1;
        //    for (int j = left; j < right; j++)
        //    {
        //        int aCPR = sequence[j].CompareTo(pivot);
        //        if (aCPR > 0)
        //        {
        //            i++;
        //            temp = sequence[j];
        //            sequence[j] = sequence[i];
        //            sequence[i] = temp;
        //        }
        //    }

        //    sequence[right] = sequence[i+1];
        //    sequence[i+1] = pivot;

        //    return i;
        //}

        static void RandQuickSort<K>(K[] sequence, int start, int end) where K : IComparable<K>
        {
            if (start < end)
            {
                //stores the position of pivot element
                int piv_pos = partition(sequence, start, end);
                RandQuickSort(sequence, start, piv_pos - 1);    //sorts the left side of pivot.
                RandQuickSort(sequence, piv_pos + 1, end); //sorts the right side of pivot.
            }
        }
        static int partition<K>(K[] arr, int start, int end) where K : IComparable<K>
        {
            int i = start - 1;
            K piv = arr[end];            //make the last element as pivot element.
            for (int j = start; j <= end - 1; j++)
            {
                /*rearrange the array by putting elements which are less than pivot
                on left side and which are greater than pivot on right side. */

                int aCPR = arr[j].CompareTo(piv);
                if (aCPR < 0)
                {
                    i++;
                    swap(ref arr[i], ref arr[j]);
                }
            }
            swap(ref arr[end], ref arr[i + 1]);  //put the pivot element in its proper place.
            return i + 1;                      //return the position of the pivot
        }

        public static void swap<K>(ref K a, ref K b) where K : IComparable<K>
        {
            K temp = a;
            a = b;
            b = temp;
        }

        public void Sort<K>(K[] sequence, IComparer<K> comparer) where K : IComparable<K>
        {

            int low = 0;
            int high = sequence.Length-1;

            RandQuickSort(sequence, low, high);
        }
    }
}