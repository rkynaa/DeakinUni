    class TestAccount
    {
        static void Main(string[] args)
        {
            Account rakyan = new Account("Rakyan", 0);

            rakyan.deposit(1000);
            rakyan.withdraw(10);
            rakyan.withdraw(1000);
            rakyan.print();
            Console.ReadLine();
        }
    }