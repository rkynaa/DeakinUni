class TestMyTime
    {
        static void Main(string[] args)
        {
            MyTime currTime = new MyTime();
            currTime.SetTime(23, 59, 59);
            Console.WriteLine("Current time: " + currTime.ToString());
            currTime = currTime.NextSecond();
            Console.WriteLine("Current time: " + currTime.ToString());
            currTime = currTime.NextMinute();
            Console.WriteLine("Current time: " + currTime.ToString());
            currTime = currTime.NextHour();
            Console.WriteLine("Current time: " + currTime.ToString());
            currTime = currTime.PreviousSecond();
            Console.WriteLine("Current time: " + currTime.ToString());
            currTime = currTime.PreviousMinute();
            Console.WriteLine("Current time: " + currTime.ToString());
            currTime = currTime.PreviousHour();
            Console.WriteLine("Current time: " + currTime.ToString());
        }
    }