class MyTime
    {
        // Instance variable
        private int hour, minute, second;
        public MyTime(int hour, int minute, int second)
        {
            if (hour >= 0 && hour <= 23)
            {
                this.hour = hour;
            }
            else
            {
                Console.WriteLine("Error: hour must be between 0 and 23!");
                return;
            }

            if (minute >= 0 && minute <= 59)
            {
                this.minute = minute;
            }
            else
            {
                Console.WriteLine("Error: minute must be between 0 and 59");
                return;
            }

            if (second >= 0 && second <= 59)
            {
                this.second = second;
            }
            else
            {
                Console.WriteLine("Error: second must be between 0 and 59");
                return;
            }
        }

        public MyTime()
        {
            this.hour = -1;
            this.minute = -1;
            this.second = -1;
        }

        public void SetTime(int hour, int minute, int second)
        {
            if (hour >= 0 && hour <= 23)
            {
                this.hour = hour;
            }
            else
            {
                Console.WriteLine("Error: hour must be between 0 and 23!");
                return;
            }

            if (minute >= 0 && minute <= 59)
            {
                this.minute = minute;
            }
            else
            {
                Console.WriteLine("Error: minute must be between 0 and 59");
                return;
            }

            if (second >= 0 && second <= 59)
            {
                this.second = second;
            }
            else
            {
                Console.WriteLine("Error: second must be between 0 and 59");
                return;
            }
        }

        public void SetHour(int hour)
        {
            if (hour >= 0 && hour <= 23)
            {
                this.hour = hour;
            }
            else
            {
                Console.WriteLine("Error: hour must be between 0 and 23!");
                return;
            }
        }

        public void SetMinute(int minute)
        {
            if (minute >= 0 && minute <= 59)
            {
                this.minute = minute;
            }
            else
            {
                Console.WriteLine("Error: minute must be between 0 and 59");
                return;
            }
        }

        public void SetSecond(int second)
        {
            if (second >= 0 && second <= 59)
            {
                this.second = second;
            }
            else
            {
                Console.WriteLine("Error: second must be between 0 and 59");
                return;
            }
        }

        public int GetHour()
        {
            if (this.hour == -1)
            {
                Console.WriteLine("Error: you haven't set the hour!");
            }
            return this.hour;
        }

        public int GetMinute()
        {
            if (this.minute == -1)
            {
                Console.WriteLine("Error: you haven't set the minute!");
            }
            return this.minute;
        }

        public int GetSecond()
        {
            if (this.second == -1)
            {
                Console.WriteLine("Error: you haven't set the minute!");
            }
            return this.second;
        }

        public String ToString()
        {
            String result = "";
            String hourStr = "", minStr = "", secStr = "";
            if (this.hour == -1 || this.minute == -1 || this.second == -1)
            {
                return "na:na:na";
            }
            else
            {
                if (this.hour >= 0 && this.hour <= 9)
                {
                    hourStr = String.Concat("0", Convert.ToString(this.hour)); 
                }
                else
                {
                    hourStr = Convert.ToString(this.hour);
                }
                if (this.minute >= 0 && this.minute <= 9)
                {
                    minStr = String.Concat("0", Convert.ToString(this.minute)); 
                }
                else
                {
                    minStr = Convert.ToString(this.minute);
                }
                if (this.second >= 0 && this.second <= 9)
                {
                    secStr = String.Concat("0", Convert.ToString(this.second)); 
                }
                else
                {
                    secStr = Convert.ToString(this.second);
                }
                result = String.Concat(hourStr, ":", minStr, ":", secStr);
                return result;
            }
        }

        public MyTime NextSecond()
        {
            if (this.second == 59)
            {
                this.second = 0;
                if (this.minute == 59)
                {
                    this.minute = 0;
                    if (this.hour == 23)
                    {
                        this.hour = 0;
                    }
                    else
                    {
                        this.hour++;
                    }
                }
                else
                {
                    this.minute++;
                }
            }
            else
            {
                this.second++;
            }
            return this;
        }

        public MyTime NextMinute()
        {
            if (this.minute == 59)
            {
                this.minute = 0;
                if (this.hour == 23)
                {
                    this.hour = 0;
                }
                else
                {
                    this.hour++;
                }
            }
            else
            {
                this.minute++;
            }
            return this;
        }
        public MyTime NextHour()
        {
            if (this.hour == 23)
            {
                this.hour = 0;
            }
            else
            {
                this.hour++;
            }
            return this;
        }

        public MyTime PreviousSecond()
        {
            if (this.second == 0)
            {
                if (this.minute == 0)
                {
                    if (this.hour == 0)
                    {
                        this.hour = 23;
                    }
                    else {
                        this.hour--;
                    }
                    this.minute = 59;
                }
                else
                {
                    this.minute--;
                }
                this.second = 59;
            }
            else
            {
                this.second--;
            }
            return this;
        }

        public MyTime PreviousMinute()
        {
            if (this.minute == 0)
            {
                if (this.hour == 0)
                {
                    this.hour = 23;
                }
                else
                {
                    this.hour--;
                }
                this.minute = 59;
            }
            else
            {
                this.minute--;
            }
            return this;
        }
        
        public MyTime PreviousHour()
        {
            if (this.hour == 0)
            {
                this.hour = 23;
            }
            else
            {
                this.hour--;
            }
            return this;
        }
    }